function getShortMessage(arrayObject){

var formattedArray = [];
//Vérifier si le tableau en entrée est de type objet, est un array et contient au moins un élément
if(typeof arrayObject == "object" && Array.isArray(arrayObject) === true && arrayObject.length > 0){

//Vérification de chaque message et insertion dans le nouveau tableau si la condition est vérifiée	
for(var message in arrayObject){
 if(arrayObject[message].length < 50){
formattedArray.push(arrayObject[message])
 }
}
//Affichage des éléments du nouveau tableau (pour test)
if(formattedArray.length !== 0){
 for(var element in formattedArray){
console.log(formattedArray[element]);
 }
}
}
return formattedArray;
}